package Catalyst::Helper::Model::Factory;
use strict;
use warnings;

use base 'Catalyst::Helper::Model::Adaptor';

=head1 NAME

Catalyst::Helper::Model::Factory - helper for the incredibly lazy

=head1 I CAN HAS DOCS?

Yes, you can has.  See L<Catalyst::Helper::Model::Adaptor> and
C<s/Adaptor/Factory/>.

=cut

1;
