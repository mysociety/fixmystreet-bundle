package ScriptTestApp::Script::CompileTest;
use Moose;
use namespace::autoclean;

die("Does not compile");

1;
