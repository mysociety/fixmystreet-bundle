package # Hide from PAUSE
  DBIx::Class::SQLAHacks::SQLite;

use warnings;
use strict;

use base qw( DBIx::Class::SQLMaker::SQLite );

1;
