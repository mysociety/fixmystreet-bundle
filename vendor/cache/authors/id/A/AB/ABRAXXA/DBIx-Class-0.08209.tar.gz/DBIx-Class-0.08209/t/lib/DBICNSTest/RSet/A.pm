package DBICNSTest::RSet::A;

use warnings;
use strict;

use base qw/DBIx::Class::ResultSet/;
1;
