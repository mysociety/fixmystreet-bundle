package DBICTest::Schema::_no_skip_load_external::Foo;
our $skip_me = "bad mojo";
1;
