package TestRole2;

use Moose::Role;

sub test_role2_method { 'test_role2_method works' }

1;
