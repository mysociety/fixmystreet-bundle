package Foo;
use Class::Std;

package main;

$obj = Foo->new();
$obj = Bar->new();


