## our out-of-namespace mailer:
package BadMailer;

1;
